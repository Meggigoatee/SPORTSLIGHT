const Login = () => {
  return (
    <div>
      <p>로그인 페이지</p>
    </div>
  );
};

export default Login;
