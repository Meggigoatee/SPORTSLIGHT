const Signup = () => {
  return (
    <div>
      <p>회원가입 페이지</p>
    </div>
  );
};

export default Signup;
