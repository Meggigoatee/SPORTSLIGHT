const Withdraw = () => {
  return (
    <div>
      <p>탈퇴 페이지</p>
    </div>
  );
};

export default Withdraw;
