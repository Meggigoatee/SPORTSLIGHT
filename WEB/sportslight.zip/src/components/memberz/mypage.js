const MyPage = () => {
  return (
    <div>
      <p>마이 페이지 첫화면</p>
    </div>
  );
};

export default MyPage;
