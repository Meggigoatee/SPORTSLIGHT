const EditInfo = () => {
  return (
    <div>
      <p>회원정보 수정 페이지</p>
    </div>
  );
};

export default EditInfo;
