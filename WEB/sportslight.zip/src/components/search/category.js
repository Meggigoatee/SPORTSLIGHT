const Category = () => {
  return (
    <div>
      <p>카테고리 검색</p>
    </div>
  );
};

export default Category;
