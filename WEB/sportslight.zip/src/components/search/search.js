const Search = () => {
  return (
    <div>
      <p>키워드 검색</p>
    </div>
  );
};

export default Search;
