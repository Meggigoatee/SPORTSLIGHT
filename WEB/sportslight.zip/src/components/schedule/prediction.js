const Prediction = () => {
  return (
    <div>
      <p>승부예측</p>
    </div>
  );
};

export default Prediction;
