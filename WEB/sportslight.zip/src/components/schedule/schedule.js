const Schedule = () => {
  return (
    <div>
      <p>오늘의 경기</p>
    </div>
  );
};

export default Schedule;
