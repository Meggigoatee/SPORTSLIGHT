const Viewtalk = () => {
  return (
    <div>
      <p>토크 글 보기</p>
    </div>
  );
};

export default Viewtalk;
