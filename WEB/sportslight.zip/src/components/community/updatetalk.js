const Updatetalk = () => {
  return (
    <div>
      <p>토크 글 수정</p>
    </div>
  );
};

export default Updatetalk;
