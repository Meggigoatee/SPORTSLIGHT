const Writetalk = () => {
  return (
    <div>
      <p>토크 글 쓰기</p>
    </div>
  );
};

export default Writetalk;
