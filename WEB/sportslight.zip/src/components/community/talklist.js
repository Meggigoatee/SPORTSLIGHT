const Talklist = () => {
  return (
    <div>
      <p>경기토크</p>
    </div>
  );
};

export default Talklist;
