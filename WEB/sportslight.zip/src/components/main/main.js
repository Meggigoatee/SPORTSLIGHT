const Main = () => {
  return (
    <div>
      <p>메인 페이지</p>
    </div>
  );
};

export default Main;
