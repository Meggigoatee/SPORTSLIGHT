const Qna = () => {
  return (
    <div>
      <p>큐앤에이</p>
    </div>
  );
};

export default Qna;
