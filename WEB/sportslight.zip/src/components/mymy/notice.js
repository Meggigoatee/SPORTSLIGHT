const Notice = () => {
  return (
    <div>
      <p>공지사항</p>
    </div>
  );
};

export default Notice;
