const Myvideo = () => {
  return (
    <div>
      <p>즐겨찾기</p>
    </div>
  );
};

export default Myvideo;
