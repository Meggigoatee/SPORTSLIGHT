const Myteam = () => {
  return (
    <div>
      <p>나의 팀</p>
    </div>
  );
};

export default Myteam;
